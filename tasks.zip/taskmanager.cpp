#include <iostream>
#include <vector>
#include <fstream>
#include "studentmenu.cpp"
#include "tools.h"

using namespace std;

const int MAX_TASKS = 50;

struct Task {
    int group;
    string title;
    string description;
    string assignedTo;
    string dueDate;
    int progress;
};

Task tasks [MAX_TASKS];
int taskCount = 0;


void taskmenu() {

    loadTasks();

    int choice;
        cout << "\n==== task menu ====\n";
        cout << "1. Add New Task\n";
        cout << "2. View All Tasks\n";
        cout << "3. Update Task Progress\n";
        cout << "4. Delete Task\n";
        cout << "5. Save & Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1:
                if(is_leader()){addTask();}
                else{cout<<">> only leader have this privlage ! \n";}
                taskmenu();
                break;
            case 2:
                viewTasks();
                taskmenu();
                break;
            case 3:
                updateProgress();
                taskmenu();
                break;
             case 4:
                 if(is_leader()){deleteTask();}
                else{cout<<">> only leader have this privlage ! \n";}
                 taskmenu();
                break;
            case 5:
                saveTasks();
                cout << "Tasks saved.....\n";
                studmenu();
                break;
            default:
                cout << "Invalid choice! Please try again.\n";}
                return ;}


void addTask() {
    if (taskCount >= MAX_TASKS) {
         cout << "Error: Task list is full (Max 50).\n";
         return;
     }

    cin.ignore();

    cout << "\n--- Add New Task ---\n";

    cout << "Enter Task Title: ";
    getline(cin, tasks[taskCount].title);

    cout << "Enter Description: ";
    getline(cin, tasks[taskCount].description);

    cout << "Assigned To (Member Name): ";
    getline(cin, tasks[taskCount].assignedTo);

    cout << "Due Date (e.g., 2023-12-31): ";
    getline(cin, tasks[taskCount].dueDate);

    tasks[taskCount].progress = 0;

    taskCount++;
    saveTasks();
    cout << "Task added successfully!\n";

}

void viewTasks() {
    if (taskCount == 0) {
        cout << "\nNo tasks available.\n";
        return;
    }

    cout << "\n--- Current Tasks ---\n";
    for (int i = 0; i < taskCount; i++) {
        if(tasks[taskCount].group==my_group){
        cout << "ID: " << (i + 1) << endl; // Show 1-based index
        cout << "Title:       " << tasks[i].title << endl;
        cout << "Description: " << tasks[i].description << endl;
        cout << "Assigned To: " << tasks[i].assignedTo << endl;
        cout << "Due Date:    " << tasks[i].dueDate << endl;
        cout << "Progress:    " << tasks[i].progress << "%" << endl;
        cout << "------------------------\n";}
    }
}

void updateProgress() {
    if (taskCount == 0) {
        cout << "\nNo tasks to update.\n";
        return;
    }

    viewTasks();

    int id;
    cout << "Enter the ID of the task to update: ";
    cin >> id;

    // Validate ID (User sees 1 to taskCount, array is 0 to taskCount-1)
    if (id < 1 || id > taskCount) {
        cout << "Invalid Task ID.\n";
        return;
    }

    int newProgress;
    cout << "Enter new progress (0-100): ";
    cin >> newProgress;
    if (newProgress < 0 || newProgress > 100) {
        cout << "Invalid progress! Must be between 0 and 100 \n";
    } else {
        if(tasks[taskCount].group==my_group){
        tasks[id - 1].progress = newProgress;
        cout << "Progress updated successfully!\n";}
    }
}

void saveTasks() {
    ofstream outFile("tasks.txt");

    if (outFile.is_open()) {

        for (int i = 0; i < taskCount; i++) {
            outFile << my_group << endl;
            outFile << tasks[i].title << endl;
            outFile << tasks[i].description << endl;
            outFile << tasks[i].assignedTo << endl;
            outFile << tasks[i].dueDate << endl;
            outFile << tasks[i].progress << endl;
        }
        outFile.close();
    } else {
        cout << "Error: Could not save to file.\n";
    }
}


void loadTasks() {
    fstream inFile("tasks.txt",ios::in);
    if (inFile.is_open()) {
        taskCount = 0;
        while (taskCount < MAX_TASKS && (inFile>>tasks[taskCount].group)) {

            getline(inFile, tasks[taskCount].title);
            getline(inFile, tasks[taskCount].description);
            getline(inFile, tasks[taskCount].assignedTo);
            getline(inFile, tasks[taskCount].dueDate);

            inFile >> tasks[taskCount].progress;

            inFile.ignore();

            if(tasks[taskCount].group==my_group){taskCount++;}}
        inFile.close();
    } else {
        cout << "No saved tasks\n";
    }
}
void deleteTask() {
    if (taskCount == 0) {
        cout << "\nNo tasks to delete\n";
        return;
    }

    viewTasks();

    int id;
    cout << "Enter the ID of the task to delete: ";
    cin >> id;

    if (id < 1 || id > taskCount) {
        cout << "Invalid Task ID.\n";
        return;
    }

    for (int i = id - 1; i <= taskCount; i++) {
        tasks[i] = tasks[i + 1];
    }

    taskCount--;
    saveTasks();
    cout << "Task deleted successfully!\n";
}

