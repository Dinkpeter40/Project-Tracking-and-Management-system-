#pragma once
#include <iostream>
#include "values.h"
#include "class.h"
#include "fclass2.cpp"
#include "tools.h"
#include"login_signup.cpp"
#include"signature.h"
#include"messages.cpp"
#include"notification.cpp"
#include"shedule.cpp"
#include"taskmanager.cpp"
using namespace std;


//finds and display a students group

void studmenu() {
    cout<<"\n       ====WELLCOME TO STUDENTS MENU===="<<endl;
    my_group=getGroup();
    int choice=0;
    cout<<"       >> 1 for viewing your group\n       >> 2 for messages \n       >> 3 for task menu \n"<<
    "       >> 4 to modify password \n       >> 5 for notification \n       >> 6 view shedule \n       >> 7 for logout \n       :";
    cin>>choice;

    if (1==choice){
    string word;
    groupBook.open("groups.txt",ios::in);
    groupfinder(username);
    groupBook.close();
    //redirect to menu
    studmenu();}
    else if (choice==2) {
        cout<<"       ## use /exit command to exist ## \n";
        readgroupmessage(); }
    else if (choice==3)taskmenu();
    else if (choice==4) {
        cout<<"       ## use /exit command to leave\n       >> please input new password(more than 4 characters)\n       : ";
retry:
        logbook.open("logbook.txt",ios::in);
        string newpassword;
        cin>>newpassword;
        if(validatepassword(newpassword) and !(newpassword=="/exit")) {
            modify(newpassword);
            logbook.close();
            login(); }
        else if(newpassword=="/exit") {
            studmenu(); }
        else {
            cout<<"       !! weak password\n       >> retry\n";
            goto retry; } }
    else if(choice==5){
            viewnotification();
            studmenu();}
    else if(choice==6){
            viewshedule();
            studmenu();}
    else login(); }

