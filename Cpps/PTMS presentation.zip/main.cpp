#include <iostream>
#include "class.h"
#include "fclass2.cpp"
#include "tools.h"
#include"login_signup.cpp"

using namespace std;
int main() {
    login();
    return 0; }
