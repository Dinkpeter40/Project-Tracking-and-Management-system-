#pragma once
#include <fstream>
#include "tools.h"
#include "fclass2.cpp"
#include "advisormenu.cpp"
#include"studentmenu.cpp"
#include "values.h"
#include"notification.cpp"

using namespace std;

//accepts full name sequencentally
inline void collect(file &studBook, string &fname, string &mname, string &lname) {
    studBook>>fname;
    studBook>>mname;
    studBook>>lname; }


void login() {
    cout<<"        ===== LOGIN PAGE =====";
    for(int i=0; i<attemptLimit; i++) {
        ask(username, password);

        if(username=="WCUadmin" and password=="q") {
            i=0;
            adminmenu(); }

        else { //check logbook
            logbook.open("logbook.txt",ios:: in);
            bool registered=logbook.registered(username,password);
            logbook.close();

            if(username.at(3)=='A' and registered) {
                i=0;
                advisorMenu(); }

            else if(registered) {
                i=0;
                studmenu(); }
            else {
                cout<<"        !! wrong user name or password!!"; } } }
    cout<<endl<<"        !! too much attempt!!";
    exit(0); }

void sign_up() {
    cout<<"\n        ##input user credentials to creat account##";
    string username,password;
    ask(username,password);

    studBook.open("student.txt",ios::in);
    IS_STUDENT=studBook.find(username,idcol);
    collect(studBook,fname,mname,lname);
    studBook.close();

    advBook.open("advisors.txt",ios::in);
    IS_ADVISOR=advBook.find(username);
    collect(advBook,fname,mname,lname);
    advBook.close();

    logbook.open("logbook.txt",ios::in);
    bool have_account=logbook.find(username);
    logbook.close();

    // write to log book
    if((IS_ADVISOR or IS_STUDENT)and !(have_account)) {
        logbook.open("logbook.txt",ios::app);
        binwrite(username,10);
        logbook<<' ';
        binwrite(password);
        logbook<<endl;
        logbook.close();
        cout<<username<<" "<<fname<<" "<<mname<<" "<<lname<<" :signed up successfully"; }
    else if (have_account) {
        cout<<"        !! user has account!! "; }

    else {
        cout<<"        !! invalid user!!"; }
    login_menu(); }

void adminmenu() {
    cout<<"        ===== LOGGED IN AS ADMIN ===== \n        1 for sign up page\n        2 to change password\n        3 to exit\n        : ";
    int choice;
    cin>>choice;
    if (choice==1) {
        sign_up(); }
    if  (choice==2) {
        logbook.open("logbook.txt",ios::in);
        string newpassword,username;
        cout<<"       >> input new password";
        ask(username,newpassword);
        modify(newpassword,username);
        logbook.close();
        adminmenu(); }
    else login(); }

void login_menu() {
    // ask for redirection
    int choice;
    cout<<"\n \t 1 for login  page \n \t 2 for sign up page \n \t :";
    cin>>choice;
    if(choice==2) {
        sign_up(); }
    else {
        login(); } }
