#pragma once
#include <iostream>
#include "values.h"
#include "fclass2.cpp"
#include "class.h"
#include "tools.h"
#include"signature.h"

using namespace std;

void notify(string reciverid,string message){
    notificationBook.open("notification.txt",ios::app);
    notificationBook<<reciverid<<" "<<message<<endl;
    notificationBook.close();
}
void viewnotification(){
    string reciverid,message;
            notificationBook.open("notification.txt",ios::in);
            while(notificationBook>>reciverid){
            if(username==reciverid or reciverid.at(0)=='0'+my_group){
                    getline(notificationBook>>ws,message);
            cout<<">> "<<message<<endl;}}
         notificationBook.close();}

string checknotification(){
    notificationBook.open("notification.txt",ios::in);
    bool yes = notificationBook.find(username);
    notificationBook.close();
    if(yes){return "(+)";}
    else {return "(-)";}

}

