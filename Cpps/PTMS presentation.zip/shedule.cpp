#pragma once
#include <iostream>
#include "values.h"
#include "fclass2.cpp"
#include "class.h"
#include "tools.h"
#include"signature.h"
#include"notification.cpp"
using namespace std;

void addshedule(){
    string purpose,group,date;
    sheduleBook.open("shedule.txt",ios::app);
    cout << "\n        === ADD NEW SHEDULE ===\n";

    cout << "        >> enter group : ";
    getline(cin>>ws,group);
    cout << "        >> enter shedule purpose: ";
    getline(cin>>ws,purpose);
    cout << "        >> enter date (dd-mm-yy): ";
    getline(cin>>ws,date);
    sheduleBook<<group<<" "<<purpose<<" "<<date<<endl;
    sheduleBook.close();
    notify(group,"new shedule");
}
void viewshedule(){
            cout<<"        ====your shedules are==== \n";
            string shedule;
            int group;
            sheduleBook.open("shedule.txt",ios::in);
            while(sheduleBook>>group){
            if(my_group == group){
                    getline(sheduleBook>>ws,shedule);
            cout<<">> "<<shedule<<endl;}}
            sheduleBook.close();}

