#pragma once
#include <iostream>
#include "class.h"
#include "values.h"
#include "string.h"
using namespace std;

//randomizing function(for all data type arrays )
void randomizer(int num,string randomarr[]){
    int x=0;
    string temp1;
    srand(time(NULL));
    //randomizing mixer loop
    for(int i=0;i<num;i++){
       for(int j=0;j<i;j++){
            x=(rand()%i);
            temp1=randomarr[x];
            randomarr[x]=randomarr[num-1-x];
            randomarr[num-1-x]=temp1;
           }}}
void randomizer(int num,STUDENTS randomarr[]){
    int x=0;
    STUDENTS temp1;
    srand(time(NULL));
    //randomizing mixer loop
    for(int i=0;i<num;i++){
       for(int j=0;j<i;j++){
            x=(rand()%i);
            temp1=randomarr[x];
            randomarr[x]=randomarr[num-1-x];
            randomarr[num-1-x]=temp1;
           }}}

//asks and accept username and password
void ask(string & username,string & password){
       cout <<endl<< "please inter username : WCU";
       cin >> username;
       cout << "please inter password : ";
       cin >> password;
       username = "WCU" + username;
       return;}

void modify(string newpassword,string USERNAME=username){
    if(logbook.find(USERNAME)){
    logbook.seekg(0);
    fstream bufferbook;
    string tempusername;
    bufferbook.open("bufferbook.txt",ios::out);

    while(logbook>>tempusername){
    bufferbook<<tempusername<<" ";
    logbook>>password;
    if(USERNAME==tempusername){
    bufferbook<<newpassword<<" "<<endl;}
    else{bufferbook<<password<<" "<<endl;}}

    logbook.close();
    bufferbook.close();

    logbook.open("logbook.txt",ios::out);
    bufferbook.open("bufferbook.txt",ios::in);

    while(bufferbook>>tempusername){
    logbook<<tempusername<<" ";
    bufferbook>>password;
    logbook<<password<<" "<<endl;}

    logbook.close();
    bufferbook.close();
    logbook.open("logbook.txt",ios::in);
    cout<<"       >> password changed successfully\n";
    }
    else {
    cout<<"       !!user not registered!!\n";
    return ;}}

bool is_leader(){
    string word;
    groupBook.open("groups.txt",ios::in);
    groupBook.find(username);
    groupBook>>word;
    groupBook>>word;
    groupBook>>word;
    if(word=="leader"){return true;}
    else{return false;}}

int getGroup(){
    string word;
    groupBook.open("groups.txt",ios::in);
    groupBook.find("group",-groupBook.find(username));
    groupBook>>word;
    groupBook>>my_group;
    groupBook.close();
    return my_group-1;
}

 inline void binwrite(string & source,int length=15,file & book=logbook){
    char destination[length];
    static char reset[]="                                                      " ;
    strncpy(destination,reset,15);
    for(int i=0;i<source.size();i++){
    destination[i]=source.at(i);}
    book.write(destination,length);}

inline void debug(){
cout<<"good up to here";
}
inline void cpytochar(string source,char destination[]){
    for(int i=0;i<source.size();i++){
        destination[i]=source.at(i);}
}

//group finder and viewer
void groupfinder(string & keyword){
            string word;
            bool my=false;
            int i=0,last=0,beginig=0;
            string my_group[500];
        while(getline(groupBook>>ws,word)){
            my_group[i]=word;
            if(word.substr(0,keyword.size())==keyword){
                my=true;}

            if(word=="end" && my){
                last=i;
                break;}
            else if(word=="end"){
                beginig=i+1;}
                i++;}

            for(int i=beginig;i<last;i++){
                cout<<my_group[i]<<endl;}}
inline bool validatepassword(string password){
    if (password.size()>=4)return true;
    else return false;
}
inline bool inrange(double number,double minimum,double maximum){
    if (minimum<=number and number<=maximum){return true;}
    else return false;
}
