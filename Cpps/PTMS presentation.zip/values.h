#pragma once
#include "fclass2.cpp"
#include <iostream>
using namespace std;

const int attemptLimit=3;
enum row {idcol=0,fnamecol=11,mnamecol=27,lnamecol=43,gendercol=59,gpacol=61,studjump=66,logjump=1 };
file projectBook,studBook,groupBook, messageBook,logbook,advBook,notificationBook,sheduleBook;;
string username,fname,mname, password,lname;
int group_count, member_count,lead_count,my_group;
bool IS_ADVISOR=false,IS_STUDENT=false,IS_LEADER=false;

//grouping
STUDENTS members[100];
STUDENTS leaders[100];
string  projects[50],projectname;

//task limit
const int MAX_TASKS = 50;
const int MAX_MY_TASKS = 500;
Task my_tasks [MAX_TASKS];
Task tasks [MAX_MY_TASKS];
int taskCount = 0,totalTaskCount=0;

