#include <iostream>
#include <vector>
#include <fstream>
#include "studentmenu.cpp"
#include "tools.h"
#include "values.h"
#include "class.h"
using namespace std;

void taskmenu() {
    //identifying users
    if(username.at(3)=='A'){IS_ADVISOR=true;}
    bool IS_LEADER=is_leader();

    loadTasks();
    int choice;
    cout << "\n        ==== TASK MENU ====\n";
    cout << "        >>1 exit\n";
    cout << "        >>2 view all tasks\n";
    if(IS_ADVISOR){
    cout << "        >>3 give feedback\n";}
    else{
    cout << "        >>3 update task progress\n";}
    if(IS_LEADER) {
        cout << "        >>4 delete task\n";
        cout << "        >>5 add new task\n"; }
    cout << "        : ";
    cin >> choice;
    switch (choice) {
    case 1:
        saveTasks();
        if(IS_ADVISOR){advisorMenu();}
                studmenu();
        break;
    case 2:
        viewTasks();
        saveTasks();
        taskmenu();
        break;
    case 3:
        if(IS_ADVISOR){givefeedback();}
        else{updateProgress();}
        taskmenu();
        break;
    case 4:
        if(!IS_LEADER) {
            cout<<"        !! invalid choice! please try again !! \n"; }
        deleteTask();
        taskmenu();
        break;
    case 5:
        if(!IS_LEADER and IS_STUDENT) {
            cout<<"        !! invalid choice! please try again !! \n"; }
        addTask();
        taskmenu();
        break;
    default: if(IS_ADVISOR){advisorMenu();}
                studmenu();
        }}


void addTask() {
    string assigneduser;
    cout << "\n        === ADD NEW TASK ===\n";

    cout << "        >> enter task title: ";
    getline(cin>>ws, my_tasks[taskCount].title);

    cout << "        >> enter description: ";
    getline(cin>>ws, my_tasks[taskCount].description);

    cout << "        >> assigned member id: WCU";
    getline(cin>>ws, assigneduser);
    my_tasks[taskCount].assignedTo="WCU"+assigneduser;

    cout << "        >> due date (dd-mm-yy): ";
    getline(cin>>ws, my_tasks[taskCount].dueDate);

    my_tasks[taskCount].progress = 0;

    taskCount++;
    saveTasks();
    cout << "        >> task added successfully\n";

}

void viewTasks() {
    if (taskCount == 0) {
        cout << "\n        !!no tasks available!!\n";
        return; }

    cout << "\n        === CURRENT TASKS ===\n";
    for (int i = 0; i < taskCount; i++) {
        cout << "id: " << (i + 1) << endl; // Show 1 based index
        cout << "title:       " << my_tasks[i].title << endl;
        cout << "description: " << my_tasks[i].description << endl;
        cout << "assigned To: " << my_tasks[i].assignedTo << endl;
        cout << "due date:    " << my_tasks[i].dueDate << endl;
        cout << "progress:    " << my_tasks[i].progress << "%" << endl;
        cout << "feedback:    " << my_tasks[i].feedback << endl;
        cout << "------------------------\n"; } }

void updateProgress() {
    if (bool(taskCount)) {
        viewTasks();
        int id,newProgress;
        cout << "enter the ID of the task to update: ";
        cin >> id;
        if(username!=my_tasks[id-1].assignedTo and inrange(id,0,taskCount)){
                cout << "        !!task is not assigned to you!! \n";
                return ;}
        else if(!inrange(id,0,taskCount)){
                cout << "        !!id out of range!! \n";
                return ;}
        else{
        cout << "enter new progress (0-100): ";
        cin >> newProgress;
        if (inrange(newProgress,0,100)) {
            my_tasks[id-1].progress = newProgress;
            cout << "        >>progress updated successfully \n";
            saveTasks(); }
        else {
            cout << "\n        !!progress out of range!!\n"; }}}

    else {
        cout << "\n        !!no tasks to update!!\n";
        return; } }


//save tasks
void saveTasks() {
    fstream outFile("tasks.txt",ios::out);

    if (outFile.is_open()) {
        //saving my groups task
        for (int i = 0; i < taskCount; i++) {
            outFile << my_group << endl;
            outFile << my_tasks[i].title << endl;
            outFile << my_tasks[i].description << endl;
            outFile << my_tasks[i].assignedTo << endl;
            outFile << my_tasks[i].dueDate << endl;
            outFile << my_tasks[i].feedback << endl;
            outFile << my_tasks[i].progress << endl; }
        //saving other group tasks
        for (int i = 0; i < totalTaskCount; i++) {
            outFile << my_group << endl;
            outFile << tasks[i].title << endl;
            outFile << tasks[i].description << endl;
            outFile << tasks[i].assignedTo << endl;
            outFile << tasks[i].dueDate << endl;
            outFile << tasks[i].feedback << endl;
            outFile << tasks[i].progress << endl; }
        outFile.close(); }
    else {
        cout << "        !!could not save to file!! \n"; } }

//loads group tasks
void loadTasks() {
    int group;
    fstream inFile("tasks.txt",ios::in);
    if (inFile.is_open()) {
        taskCount = 0;
        totalTaskCount=0;
        while (inFile>>group) {
            //loads only my group tasks
            if(group==my_group) {
                tasks[taskCount].group=group;
                getline(inFile>>ws, my_tasks[taskCount].title);
                getline(inFile>>ws, my_tasks[taskCount].description);
                getline(inFile>>ws, my_tasks[taskCount].assignedTo);
                getline(inFile>>ws, my_tasks[taskCount].dueDate);
                getline(inFile>>ws, my_tasks[taskCount].feedback);
                inFile >> my_tasks[taskCount].progress;
                taskCount++; }

            //loading other groups task
            else {
                tasks[taskCount].group=group;
                getline(inFile, tasks[taskCount].title);
                getline(inFile, tasks[taskCount].description);
                getline(inFile, tasks[taskCount].assignedTo);
                getline(inFile, tasks[taskCount].dueDate);
                getline(inFile, tasks[taskCount].feedback);
                inFile >> tasks[taskCount].progress;
                totalTaskCount++; }}
        inFile.close(); }
    else {
        cout << "        !!no saved tasks!! \n"; } }



//delete task
void deleteTask() {
    if (taskCount == 0) {
        cout << "\n        !!no tasks to delete!! \n";
        return; }

    viewTasks();

    int id;
    cout << "enter the id of the task to delete: ";
    cin >> id;

    if (id < 1 || id > taskCount) {
        cout << "        !!invalid task id!!\n";
        return; }

    for (int i = id - 1; i <= taskCount; i++) {
        tasks[i] = tasks[i + 1]; }

    taskCount--;
    saveTasks();
    cout << "        >>task deleted successfully\n"; }

void givefeedback(){
        if (bool(taskCount)) {
        viewTasks();
        int id;
        string feedback;
        cout << "enter the ID of the task for feedback: ";
        cin >> id;
        if(!inrange(id,0,taskCount)){
                cout << "        !!id out of range!! \n";
                return ;}
        else{
        cout << "enter feedback : ";
        getline(cin >>ws,feedback);
        my_tasks[id-1].feedback = feedback;
        saveTasks();
        string notification="new feedback is given on "+my_tasks[id-1].title+" task";
        notify(my_tasks[id-1].assignedTo,notification);
        }}
    else {
        cout << "\n        !!no tasks to update!!\n";
        return; } }


