#pragma once
#include <iostream>
#include "values.h"
#include "fclass2.cpp"
#include "class.h"
#include "tools.h"
#include"login_signup.cpp"
#include"signature.h"

using namespace std;


void messageTogroup() {
    cout<<"me : ";
    messageBook.open("messages.txt",ios:: app);
    string message;
    getline(cin>>ws,message);
    //existing
    if(message=="/exit") {
        messageBook.close();
        if(username.at(3)=='A'){advisorMenu();}
        else studmenu(); }
    messageBook<<endl<<my_group<<" "<<username<<" "<<message<<endl;
    messageBook.close();
    messageTogroup(); }

void readgroupmessage () {
    string word,group,slenderid;
    group='0'+my_group;
    messageBook.open("messages.txt",ios::in);
    studBook.open("student.txt",ios::in);
    advBook.open("advisors.txt",ios::in);
    while(messageBook>>word ) {
        if(group==word) {
            messageBook>>slenderid;
            getline (messageBook>>ws,word);
            if (username==slenderid) {
                cout<<"me >> "<<word<<endl; }
            else {
                if(studBook.find(slenderid,idcol)){studBook>>slenderid;}
                else {advBook.find(slenderid,idcol);advBook>>slenderid;advBook>>slenderid;}
                cout<<slenderid<<" >> "<<word<<endl; } } }
    messageBook.close();
    studBook.close();
    advBook.close();
    messageTogroup(); }
