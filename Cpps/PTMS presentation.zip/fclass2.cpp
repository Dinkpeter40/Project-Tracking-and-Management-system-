#pragma once
#include <iostream>
#include <fstream>
using namespace std;


class file : public fstream {
public:
    string word;
public:

    //word finder in a file
    int find(string keyword,int row=-1,int jump=66) {

        // move reading cursor
        if(row==-1) {
            seekg(0); } //0 search(default)
        else if (row<-1) {
            seekg(row*-1); } //continue search
        else {
            seekg(row); } //jump search

        //search loop
        int i=0;
        while (*this>>word) {
            if(keyword==word) {
                return tellg(); }
            //jump condition
            if (row>-1) {
                seekp(row+jump*i);
                i++; } }
        return 0; }


    //credential checker
    bool registered(string keyword,string password,int row=-1,int jump=66) {
        find(keyword,row,jump);
        string tempo_password;
        *this>>tempo_password;
        if(password==tempo_password) {
            return true; }
        else {
            return false; } }

};//class ender
