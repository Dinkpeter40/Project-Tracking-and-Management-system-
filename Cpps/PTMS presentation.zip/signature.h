#pragma once
#include <fstream>
#include<iostream>

using namespace std;
//task branch
void loadTasks();
void saveTasks();
void addTask();
void viewTasks();
void updateProgress();
void deleteTask();
void taskmenu();
void loadMyTasks();
void givefeedback();
//login logout
void login_menu();
void sign_up();
void login();
void collect(file &studBook, string &fname, string &mname, string &lname);
void adminmenu();

//advisors Menu
void advisorMenu();
void add_proj();
void grouper();
void savegroup(int & member_id,int & group_id,string projects[],STUDENTS groups[100][100]);

//student Menu
void studmenu();
inline string getNdisplay(string placeholder);
void view_group();

//messages
void readgroupmessage ();
void messageTogroup();

//notification
string checknotification();
//void viewnotification();
void notify(string reciverid,string message);
