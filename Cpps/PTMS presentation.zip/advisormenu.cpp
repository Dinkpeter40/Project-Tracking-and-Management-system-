#pragma once
#include <iostream>
#include"signature.h"
#include "values.h"
#include"login_signup.cpp"
#include"studentmenu.cpp"
#include "class.h"
#include "fclass2.cpp"
#include "tools.h"
#include"notification.cpp"
#include"shedule.cpp"


using namespace std;

//student loader and classifier
inline void loadstudent(double & mingpa) {
    STUDENTS studentloader;
    member_count=0;
    lead_count=0;
    while(studBook>>studentloader.id) {
        studBook>>studentloader.fname;
        studBook>>studentloader.mname;
        studBook>>studentloader.lname;
        studBook>>studentloader.gender;
        studBook>>studentloader.gpa;
        if(studentloader.gpa>= mingpa) {
            leaders[lead_count]=studentloader;
            lead_count++; }
        else {
            members[member_count]=studentloader;
            member_count++; } } }

//group form and display
inline void formgroup(int & member_id,int & group_id,string projects[]) {
    string word;
    STUDENTS groups[100][100];
    for(int i=0; i<lead_count+member_count; i++) {
        if(group_id==lead_count) {
            group_id=0;
            member_id++; }

        if (member_id==0) {
            groups[group_id][member_id]=leaders[group_id]; }
        else {
            groups[group_id][member_id]=members[i-lead_count]; }
        group_id++; }

    for(int i=0; i<lead_count; i++) {
        cout<<"group : "<<i+1<<endl<<projects[i]<<endl;
        for(int j=0; j<member_id+1; j++) {
            cout<< groups[i][j].id<<" ";
            cout<< groups[i][j].fname<<" ";
            cout<< groups[i][j].mname<<" ";
            if(j==0) {
                cout<<"leader"; }
            cout<<endl; } }
    int choice=0;
    cout<<"        1 to save group\n        2 to exit\n        : ";
    cin>>choice;
    if(choice==1) {
        savegroup(member_id,group_id,projects,groups); }
    else {
        return ; } }

//saves the formed group
inline void savegroup(int & member_id,int & group_id,string projects[],STUDENTS groups[100][100]) {
    groupBook.open("groups.txt",ios::out);
    for(int i=0; i<lead_count; i++) {
        groupBook<<"group : "<<i+1<<endl<<projects[i]<<endl;
        for(int j=0; j<member_id+1; j++) {
            groupBook<<groups[i][j].id<<" ";
            groupBook<<groups[i][j].fname<<" ";
            groupBook<< groups[i][j].mname<<" ";
            if(j==0) {
                groupBook<<"leader"; }
            groupBook<<endl; }
        groupBook<<"end"<<endl;}
        messageBook.open("messages.txt",ios::out);
        messageBook.close();
        groupBook.close();
        cout<<"     >> successfully saved"<<endl; }

//for adding projects
void add_proj() {
    int keep=1;
    string word;
    projectBook.open("projectlist.txt",ios::app);
    cout<<"\n        ====ENTER PROJECTS===="<<endl<<"project name : ";
    getline(cin>>ws,word);
    projectBook<<endl<<word;

    //ask for user action
    cout<<"\n        1 to add more\n        2 to exit  \n        :";
    cin>>keep;
    projectBook.close();
    if(keep==1) {
        add_proj(); }
    else {
        advisorMenu(); }; }

//automatic group and project assignment
void grouper() {
    double mingpa=3.6;
    enter:
    cout<<"input minimum GPA for leader : ";
    cin>>mingpa;
    if(!inrange(mingpa,0,4)){
        cout<<"     !! invalid gpa !!\n";
            goto enter;}
    //declarations
    static int project_count=0;
    //load and separate based on gpa
    studBook.open("student.txt",ios::in);
    loadstudent(mingpa);
    studBook.close();

    if(bool(project_count)) {
        goto skip; }
    //project loader
    projectBook.open("projectlist.txt",ios::in);
    while(getline(projectBook>>ws,projects[project_count])) {
        project_count++; }
    projectBook.close();
skip:


    //shuffling
    randomizer(project_count,projects);
    randomizer(lead_count,leaders);
    randomizer(member_count,members);

    //form group
    int member_id=0,group_id=0;

    cout<<"     >>"<<lead_count<<" leaders are selected"<<endl;
    //ask for user choice(save/redo/exit)
    cout<<"\n        1 to display\n        2 main menu\n        3 redo\n        : ";
    int choice=0;
    cin>>choice;

    // saving section
    if (choice==1) {
        formgroup(member_id,group_id,projects);
        advisorMenu(); }


    else if (choice==2) {
        groupBook.close();
        advisorMenu(); }
    else {
        groupBook.close();
        grouper (); } }

void veiwgroups() {

    groupBook.open("groups.txt",ios::in);
    int choice;
    string word;

    cout<<"        >> 1 for student search\n        >> 2 for group search\n";
    cout<<"     : ";
    cin>>choice;
    if (choice==1) {
        cout<<"input student id : WCU";
        cin>>word;
        word="WCU"+word; }
    else {
        cout<<"input group number: ";
        cin>>word;
        word="group : "+word; }

    groupfinder(word);
    groupBook.close();
    advisorMenu(); }

void advisorMenu() {
    int choice;
    cout<<"\n        ==== WELLCOME TO ADVISORS MENU ====        \n";
    cout<<"        1 to add new projects\n        2 to auto group and assign projects\n        3 to view groups\n        4 to contact groups\n        5 to view tasks\n        6 Add shedule\n        7 to log out\n        : ";
    cin>>choice;
    if(choice==1) {
        add_proj(); }
    else if (choice==2) {
        grouper(); }
    else if(choice==3) {
        veiwgroups(); }
    else if(choice==4) {
        cout<<"input group number to contact : ";
        cin>>my_group;
        cout<<"       ## use /exit command to exist ## \n";
        readgroupmessage(); }
    else if(choice==5) {
        cout<<"input group number to check progress : ";
        cin>>my_group;
        taskmenu(); }
    else if(choice==6) {
        addshedule();
        advisorMenu(); }

    else {
        login(); } }

