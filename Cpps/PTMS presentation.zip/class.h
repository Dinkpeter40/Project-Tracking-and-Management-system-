#pragma once
#include <iostream>
using namespace std;
struct shedule {
    int group;
    string purpose;
    string Date;
     };
struct Task {
    int group;
    string title;
    string description;
    string assignedTo;
    string dueDate;
    int progress;
    string feedback;
     };

class STUDENTS{
    public:
    string id;
    string fname;
    string mname;
    string lname;
    char gender;
    double gpa;
    string group;

    public:
    STUDENTS(string ID,string FNAME,string MNAME ,
    string LNAME,char GENDER,float GPA){
    id=ID;
    fname=FNAME;
    mname=MNAME;
    lname=LNAME;
    gender=GENDER;
    gpa=GPA;
    }
    STUDENTS(){};
    };
